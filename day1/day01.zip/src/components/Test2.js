import React from 'react';

const Test2 = () => {
    // 함수영역
    const title = "신상 명세서";
    const name = "홍길동";
    const addr = "서울";
    const tel = "010-1111-2222";
    const sex = "남자";
    const age = 20;

    return (
        <>
            <h1>JSX 영역</h1>   
            <h2>타이틀: {title} </h2> 
            <ul>
                <li>이름: {name} </li>
                <li>나이: {age} </li>
                <li>주소: {addr} </li>
                <li>전화: {tel} </li>
                <li>성별: {sex} </li>
            </ul>  
        </>
    );
};

export default Test2;
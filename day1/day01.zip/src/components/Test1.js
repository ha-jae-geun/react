import React from 'react';

const Test1 = () => {
    return (
        <>
           <h1>JSX 영역</h1>
           <p>한 줄 이상일 경우 반드시 div로 묶어준다.</p>
           <p> Fragment 의미 없는 묶음</p>
           <img src="" alt="빈 태그" />
           <input type="text" />
        </>
    );
};

export default Test1;
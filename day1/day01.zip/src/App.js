import React from 'react'
import Test2 from './components/Test2'
// import 참조변수 컴포먼트명과 동일 권장 from '경로'

const App = () => {

  return(
    <div>
      테스트
      <Test2 />
    </div>
  )
}

export default App